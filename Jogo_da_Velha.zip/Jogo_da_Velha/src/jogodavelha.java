import java.util.Objects;
import java.util.Random;
import java.util.Scanner;

public class jogodavelha {
    static Scanner ler = new Scanner(System.in);
    String[][] t={{"1","2","3"},{"4","5","6"},{"7","8","9"}};
    static int vencedor = 0;
    public static String modoJogo="0";
    public static int jogadas=0;
    public void tabuleiro(){
        for(int l=0;l<3;l++){
            for(int c=0;c<3;c++){
                System.out.printf("   "+t[l][c]);
            }
            System.out.println(" ");
        }
    }

    public boolean validarJogada(String p){
        for(int l=0;l<3;l++){
            for(int c=0;c<3;c++){
                if (t[l][c].equals(p)){
                    return false;
                }
            }
        }
        return true;
    }

    public void jogada(String p, String j){
        switch (p) {
            case "1" -> t[0][0] = j;
            case "2" -> t[0][1] = j;
            case "3" -> t[0][2] = j;
            case "4" -> t[1][0] = j; //00 01 02
            case "5" -> t[1][1] = j; //10 11 12
            case "6" -> t[1][2] = j; //20 21 22
            case "7" -> t[2][0] = j;
            case "8" -> t[2][1] = j;
            case "9" -> t[2][2] = j;
        }
    }

    public void verificarVencedor(String p){
        if(modoJogo.equals("1")){
            if(t[0][0].equals("X") &&t[0][1].equals("X") &&t[0][2].equals("X")){
                vencedor=1;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[1][0].equals("X") &&t[1][1].equals("X") &&t[1][2].equals("X")){
                vencedor=1;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[2][0].equals("X") &&t[2][1].equals("X") &&t[2][2].equals("X")){
                vencedor=1;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[0][0].equals("X") &&t[1][0].equals("X") &&t[2][0].equals("X")){
                vencedor=1;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[0][1].equals("X") &&t[1][1].equals("X") &&t[2][1].equals("X")){
                vencedor=1;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[0][2].equals("X") &&t[1][2].equals("X") &&t[2][2].equals("X")){
                vencedor=1;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[0][0].equals("X") &&t[1][1].equals("X") &&t[2][2].equals("X")){
                vencedor=1;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[0][2].equals("X") &&t[1][1].equals("X") &&t[2][0].equals("X")){
                vencedor=1;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[0][0].equals("O") &&t[0][1].equals("O") &&t[0][2].equals("O")){
                vencedor=2;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[1][0].equals("O") &&t[1][1].equals("O") &&t[1][2].equals("O")){
                vencedor=2;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[2][0].equals("O") &&t[2][1].equals("O") &&t[2][2].equals("O")){
                vencedor=2;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[0][0].equals("O") &&t[1][0].equals("O") &&t[2][0].equals("O")){
                vencedor=2;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[0][1].equals("O") &&t[1][1].equals("O") &&t[2][1].equals("O")){
                vencedor=2;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[0][2].equals("O") &&t[1][2].equals("O") &&t[2][2].equals("O")){
                vencedor=2;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[0][0].equals("O") &&t[1][1].equals("O") &&t[2][2].equals("O")){
                vencedor=2;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[0][2].equals("O") &&t[1][1].equals("O") &&t[2][0].equals("O")){
                vencedor=2;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(jogadas==8){
                vencedor=3;
                modoJogo="0";
                System.out.println("Empate!");
            }}
        if(modoJogo.equals("2")){
            if(t[0][0].equals("X") &&t[0][1].equals("X") &&t[0][2].equals("X")){
                vencedor=1;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[1][0].equals("X") &&t[1][1].equals("X") &&t[1][2].equals("X")){
                vencedor=1;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[2][0].equals("X") &&t[2][1].equals("X") &&t[2][2].equals("X")){
                vencedor=1;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[0][0].equals("X") &&t[1][0].equals("X") &&t[2][0].equals("X")){
                vencedor=1;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[0][1].equals("X") &&t[1][1].equals("X") &&t[2][1].equals("X")){
                vencedor=1;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[0][2].equals("X") &&t[1][2].equals("X") &&t[2][2].equals("X")){
                vencedor=1;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[0][0].equals("X") &&t[1][1].equals("X") &&t[2][2].equals("X")){
                vencedor=1;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[0][2].equals("X") &&t[1][1].equals("X") &&t[2][0].equals("X")){
                vencedor=1;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("Jogador "+vencedor+" venceu!");
            }
            else if(t[0][0].equals("O") &&t[0][1].equals("O") &&t[0][2].equals("O")){
                vencedor=2;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("O computador venceu!");
            }
            else if(t[1][0].equals("O") &&t[1][1].equals("O") &&t[1][2].equals("O")){
                vencedor=2;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("O computador venceu!");
            }
            else if(t[2][0].equals("O") &&t[2][1].equals("O") &&t[2][2].equals("O")){
                vencedor=2;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("O computador venceu!");
            }
            else if(t[0][0].equals("O") &&t[1][0].equals("O") &&t[2][0].equals("O")){
                vencedor=2;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("O computador venceu!");
            }
            else if(t[0][1].equals("O") &&t[1][1].equals("O") &&t[2][1].equals("O")){
                vencedor=2;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("O computador venceu!");
            }
            else if(t[0][2].equals("O") &&t[1][2].equals("O") &&t[2][2].equals("O")){
                vencedor=2;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("O computador venceu!");
            }
            else if(t[0][0].equals("O") &&t[1][1].equals("O") &&t[2][2].equals("O")){
                vencedor=2;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("O computador venceu!");
            }
            else if(t[0][2].equals("O") &&t[1][1].equals("O") &&t[2][0].equals("O")){
                vencedor=2;
                modoJogo="0";
                System.out.println(" ");
                System.out.println("O computador venceu!");
            }
            else if(jogadas==8){
                vencedor=3;
                modoJogo="0";
                System.out.println("Empate!");
                System.out.println(" ");
            }}
    }

    public void mododejogo(){
        if(modoJogo.equals("0")){
            System.out.println(" ");
            System.out.println("Escolha o modo de jogo:");
            System.out.println(" ");
            System.out.println("Jogador contra jogador: digite 1.");
            System.out.println(" ");
            System.out.println("Jogador contra maquina: digite 2.");
            System.out.println(" ");
            System.out.println("Sair do jogo: digite 3.");
            System.out.println(" ");
            modoJogo = ler.next();
            while(!Objects.equals(modoJogo, "0") &&!Objects.equals(modoJogo, "1")&&!Objects.equals(modoJogo, "2")&&!Objects.equals(modoJogo, "3")){
                System.out.println("Modo de jogo inválido, tente novamente.");
                modoJogo = ler.next();
            }
        }
    }

    public static void jogo(){
        while(true){
            jogodavelha jogo=new jogodavelha();
            jogo.mododejogo();
            if (modoJogo.equals("3")){
                break;
            }
            jogo.tabuleiro();
            String posicao;
            jogadas=0;
            while(modoJogo.equals("1")){
                vencedor=0;
                System.out.println(" ");
                System.out.println("Jogador 1, informe uma posição: ");
                System.out.println(" ");
                posicao = ler.next();
                while(jogo.validarJogada(posicao)){
                    System.out.println(" ");
                    System.out.println("Jogada invalida!");
                    System.out.println("Jogador 1, informe uma posição: ");
                    System.out.println(" ");
                    posicao = ler.next();
                }
                jogo.jogada(posicao, "X");
                jogo.tabuleiro();
                jogo.verificarVencedor(posicao);
                jogadas++;
                if (vencedor==0){
                    System.out.println(" ");
                    System.out.println("Jogador 2, informe uma posição: ");
                    System.out.println(" ");
                    posicao = ler.next();
                    while(jogo.validarJogada(posicao)){
                        System.out.println(" ");
                        System.out.println("Jogada invalida!");
                        System.out.println("Jogador 2, informe uma posição: ");
                        System.out.println(" ");
                        posicao = ler.next();
                    }
                    jogo.jogada(posicao, "O");
                    jogo.tabuleiro();
                    jogo.verificarVencedor(posicao);
                    jogadas++;
                }
            } //Jogador vs Jogador

            while(modoJogo.equals("2")){
                vencedor=0;
                System.out.println(" ");
                System.out.println("Jogador 1, informe uma posição: ");
                System.out.println(" ");
                posicao = ler.next();
                while(jogo.validarJogada(posicao)){
                    System.out.println(" ");
                    System.out.println("Jogada invalida!");
                    System.out.println("Jogador 1, informe uma posição: ");
                    System.out.println(" ");
                    posicao = ler.next();
                }
                jogo.jogada(posicao, "X");
                jogo.tabuleiro();
                jogo.verificarVencedor(posicao);
                jogadas++;
                if(vencedor==0){
                    Random rand=new Random();
                    int random=rand.nextInt(9)+1;
                    String posicao1=String.valueOf(random);
                    System.out.println(" ");
                    System.out.println("Vez do computador: ");
                    System.out.println(" ");
                    while(jogo.validarJogada(posicao1)){
                        random=rand.nextInt(9)+1;
                        posicao1=String.valueOf(random);
                    }
                    jogo.jogada((posicao1), "O");
                    jogo.tabuleiro();
                    jogo.verificarVencedor(posicao1);
                    jogadas++;
                }
            } //Jogador VS Computador
        }
    }

    public static void main(String[] args) {
        jogo();
    }
}